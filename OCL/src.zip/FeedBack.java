public class FeedBack {
	String Id;
	String user;
	String text;
	String date;
	String answer;
	String category;
	String status;

	public FeedBack(String Id, String user, String text, String date,
			String answer, String status, String category) {
		this.Id = Id;
		this.user = user;
		this.text = text;
		this.date = date;
		this.answer = answer;
		this.status = status;
		this.category = category;
	}

	public String toString() {
		String result = "----------\nfeedback:\nId: " + Id + "\n date: " + date
				+ "\n text:" + text + "\n status: " + status + "\n category: "
				+ category + "\n answer: " + answer+"\n----------";
		return result;
	}
}
