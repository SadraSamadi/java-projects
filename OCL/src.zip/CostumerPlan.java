public class CostumerPlan {
	String name;
	String explain;
	String category;
	String price;
	String amount;
	String Id;

	public CostumerPlan(String Id, String name, String explain,
			String category, String price, String amount) {
		this.Id = Id;
		this.name = name;
		this.explain = explain;
		this.category = category;
		this.price = price;
		this.amount = amount;
	}

	public String toString() {
		String result = "\n***\nplan:";
		result += "\nId: " + Id;
		result += "\nname: " + name;
		result += "\ncategory: " + category;
		result += "\nexplain: " + explain;
		result += "\nprice: " + price;
		result += "\namount: " + amount;
		result += "\n";
		return result;
	}
}
