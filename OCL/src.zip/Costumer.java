import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class Costumer {
	int Id = -1;
	String name = "";
	String address = "";
	double score = -1;
	String username = "";
	String password = "";
	String email = "";
	String call = "";
	ArrayList<CostumerPlan> plans = new ArrayList<CostumerPlan>();

	public Costumer(int Id, String name, double score) {
		this.Id = Id;
		this.name = name;
		this.score = score;
	}

	public Costumer() {

	}

	public void getPlans() {
		String USER_AGENT = "Mozilla/5.0";
		URL obj;
		try {
			obj = new URL("http://onchapline.ir/ocl_cli/coustmerPlanById.php");
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty("User-Agent", USER_AGENT);
			// For POST only - START
			con.setDoOutput(true);
			OutputStream os = con.getOutputStream();
			os.write(("costumer_id=" + Id).getBytes());
			os.flush();
			os.close();
			// For POST only - END

			int responseCode = con.getResponseCode();
			System.out.println("POST Response Code :: " + responseCode);
			if (responseCode == HttpURLConnection.HTTP_OK) { // success
				BufferedReader in = new BufferedReader(new InputStreamReader(
						con.getInputStream()));

				String inputLine;
				StringBuffer response = new StringBuffer();

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);

				}
				in.close();

				// print result
				String rs = response.toString();
				// System.out.println(rs);
				String[] services = rs.split("#002#");
				for (int k = 0; k < services.length; k++) {
					System.out.println(services[k]);
					String[] fields = services[k].split("#003#");
					plans.add(new CostumerPlan(fields[0], fields[1], fields[2],
							fields[3], fields[4], fields[5]));
				}
			} else {
				System.out.println("POST request not worked");
			}

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void getInfoById() {
		String rs = getInfo();
		if (!rs.equals("not connected") || !rs.equals("failed")) {
			{
				String[] fields = rs.split("#000#");
				address = fields[0];
				email = fields[1];
				call = fields[2];
			}
		}
	}

	private String getInfo() {
		String USER_AGENT = "Mozilla/5.0";
		URL obj;
		try {
			obj = new URL(
					"http://onchapline.ir/ocl_cli/costumerDisplayById.php");
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty("User-Agent", USER_AGENT);
			// For POST only - START
			con.setDoOutput(true);
			OutputStream os = con.getOutputStream();
			os.write(("costumer_id=" + Id).getBytes());
			os.flush();
			os.close();
			// For POST only - END

			int responseCode = con.getResponseCode();
			System.out.println("POST Response Code :: " + responseCode);
			if (responseCode == HttpURLConnection.HTTP_OK) { // success
				BufferedReader in = new BufferedReader(new InputStreamReader(
						con.getInputStream()));

				String inputLine;
				StringBuffer response = new StringBuffer();

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);

				}
				in.close();

				// print result
				return response.toString();
			} else {
				System.out.println("POST request not worked");
				return "not connected";
			}

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "not connected";
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "not connected";
		}
	}

	public String toString() {
		String result = "--------\nCostumer\n";
		result += "Id: " + Id + "\n";
		result += "name: " + name + "\n";
		result += "address: " + address + "\n";
		result += "score: " + score + "\n";
		result += "email: " + email + "\n";
		result += "call: " + call + "\n";
		for (int i = 0; i < plans.size(); i++)
			result += plans.get(i);
		result += "-------\n";
		return result;
	}
}
