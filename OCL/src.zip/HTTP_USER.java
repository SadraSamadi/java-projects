import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class HTTP_USER {


	public static ArrayList<Costumer> costumerList() {
		String rs = costumers();
		ArrayList<Costumer> result = new ArrayList<Costumer>();
		String[] costumersf = rs.split("#000#");
		for (int i = 0; i < costumersf.length; i++) {
			String[] fields = costumersf[i].split("#001#");
			result.add(new Costumer(Integer.valueOf(fields[0]), fields[1],
					Double.valueOf(fields[2])));
			result.get(result.size() - 1).getInfoById();
		}
		return result;
	}

	public static ArrayList<FeedBack> FeedBackList(String username,
			String password) {
		ArrayList<FeedBack> result = new ArrayList<FeedBack>();
		String res = getFeadbacks(username, password);
		String[] feedbacks = res.split("#000#");
		for (int i = 0; i < feedbacks.length; i++) {
			String[] fields = feedbacks[i].split("#001#");
			result.add(new FeedBack(fields[0], fields[3], fields[2], fields[4],
					fields[6], fields[5], fields[1]));
		}
		return result;
	}

	public static String costumers() {
		String USER_AGENT = "Mozilla/5.0";
		URL obj;
		try {
			obj = new URL("http://onchapline.ir/ocl_cli/costumerDisplay.php");
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty("User-Agent", USER_AGENT);

			// For POST only - START
			con.setDoOutput(true);
			// For POST only - END

			int responseCode = con.getResponseCode();
			System.out.println("POST Response Code :: " + responseCode);
			if (responseCode == HttpURLConnection.HTTP_OK) { // success
				BufferedReader in = new BufferedReader(new InputStreamReader(
						con.getInputStream()));
				String inputLine;
				StringBuffer response = new StringBuffer();

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();

				// print result
				return response.toString();
			} else {
				System.out.println("POST request not worked");
				return "not connected";
			}

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "not connected";
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "not connected";
		}

	}

	public static String getFeadbacks(String username, String passwd) {
		String USER_AGENT = "Mozilla/5.0";
		URL obj;
		try {
			obj = new URL("http://onchapline.ir/ocl_cli/feedbackDisplay.php");
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty("User-Agent", USER_AGENT);

			// For POST only - START
			con.setDoOutput(true);
			OutputStream os = con.getOutputStream();
			os.write(("feedback_username=" + username).getBytes());
			os.write(("&feedback_password=" + passwd).getBytes());
			os.flush();
			os.close();
			// For POST only - END

			int responseCode = con.getResponseCode();
			System.out.println("POST Response Code :: " + responseCode);
			if (responseCode == HttpURLConnection.HTTP_OK) { // success
				BufferedReader in = new BufferedReader(new InputStreamReader(
						con.getInputStream()));
				String inputLine;
				StringBuffer response = new StringBuffer();

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();

				// print result
				return response.toString();
			} else {
				System.out.println("POST request not worked");
				return "not connected";
			}

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "not connected";
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "not connected";
		}

	}

	public static String sendFeedBack(String username, String passwd,
			String category, String text, String date) {
		String USER_AGENT = "Mozilla/5.0";
		URL obj;
		try {
			obj = new URL("http://onchapline.ir/ocl_cli/feedback.php");
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty("User-Agent", USER_AGENT);

			// For POST only - START
			con.setDoOutput(true);
			OutputStream os = con.getOutputStream();
			os.write(("feedback_username=" + username).getBytes());
			os.write(("&feedback_password=" + passwd).getBytes());
			os.write(("&feedback_category=" + category).getBytes());
			os.write(("&feedback_text=" + text).getBytes());
			os.write(("&feedback_date=" + date).getBytes());
			os.flush();
			os.close();
			// For POST only - END

			int responseCode = con.getResponseCode();
			System.out.println("POST Response Code :: " + responseCode);
			if (responseCode == HttpURLConnection.HTTP_OK) { // success
				BufferedReader in = new BufferedReader(new InputStreamReader(
						con.getInputStream()));
				String inputLine;
				StringBuffer response = new StringBuffer();

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();

				// print result
				return response.toString();
			} else {
				System.out.println("POST request not worked");
				return "not connected";
			}

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "not connected";
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "not connected";
		}

	}

	public static Costumer getCostumerInfo(String username, String passwd) {
		String USER_AGENT = "Mozilla/5.0";
		URL obj;
		try {
			obj = new URL(
					"http://onchapline.ir/ocl_cli/costumerDisplayByUsername.php");
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty("User-Agent", USER_AGENT);

			// For POST only - START
			con.setDoOutput(true);
			OutputStream os = con.getOutputStream();
			os.write(("costumer_username=" + username).getBytes());
			os.write(("&costumer_password=" + passwd).getBytes());
			os.flush();
			os.close();
			// For POST only - END

			int responseCode = con.getResponseCode();
			System.out.println("POST Response Code :: " + responseCode);
			if (responseCode == HttpURLConnection.HTTP_OK) { // success
				BufferedReader in = new BufferedReader(new InputStreamReader(
						con.getInputStream()));
				String inputLine;
				StringBuffer response = new StringBuffer();

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();

				// print result
				String result = response.toString();
				Costumer c = new Costumer();
				String[] field = result.split("#000#");
				c.Id = Integer.valueOf(field[0]);
				c.name = field[1];
				c.address = field[2];
				c.score = Double.valueOf(field[3]);
				c.getPlans();
				c.username = field[5];
				c.password = field[6];
				c.email = field[7];
				c.call = field[8];
				// c.news = field[9]
				return c;
			} else {
				System.out.println("POST request not worked");
				return null;
			}

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}

	public static String costumerLogin(String username, String passwd) {
		String USER_AGENT = "Mozilla/5.0";
		URL obj;
		try {
			obj = new URL("http://onchapline.ir/ocl_cli/costumerLogin.php");
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty("User-Agent", USER_AGENT);

			// For POST only - START
			con.setDoOutput(true);
			OutputStream os = con.getOutputStream();
			os.write(("username=" + username).getBytes());
			os.write(("&passwd=" + passwd).getBytes());
			os.flush();
			os.close();
			// For POST only - END

			int responseCode = con.getResponseCode();
			System.out.println("POST Response Code :: " + responseCode);
			if (responseCode == HttpURLConnection.HTTP_OK) { // success
				BufferedReader in = new BufferedReader(new InputStreamReader(
						con.getInputStream()));
				String inputLine;
				StringBuffer response = new StringBuffer();

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();

				// print result
				return response.toString();
			} else {
				System.out.println("POST request not worked");
				return "not connected";
			}

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "not connected";
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "not connected";
		}

	}

	public static String usersLogin(String username, String passwd) {
		String USER_AGENT = "Mozilla/5.0";

		URL obj;
		try {
			obj = new URL("http://onchapline.ir/ocl_cli/login.php");
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty("User-Agent", USER_AGENT);

			// For POST only - START
			con.setDoOutput(true);
			OutputStream os = con.getOutputStream();
			os.write(("username=" + username).getBytes());
			os.write(("&passwd=" + passwd).getBytes());
			os.flush();
			os.close();
			// For POST only - END

			int responseCode = con.getResponseCode();
			System.out.println("POST Response Code :: " + responseCode);
			if (responseCode == HttpURLConnection.HTTP_OK) { // success
				BufferedReader in = new BufferedReader(new InputStreamReader(
						con.getInputStream()));
				String inputLine;
				StringBuffer response = new StringBuffer();

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();

				// print result
				return response.toString();
			} else {
				System.out.println("POST request not worked");
				return "not connected";
			}

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "not connected";
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "not connected";
		}

	}

	// 0: done
	// 1: failed
	// 2: not connected
	public static String users_Register(String username, String passwd,
			String email, String fullname, String addrass) {
		String USER_AGENT = "Mozilla/5.0";

		URL obj;
		try {
			obj = new URL("http://onchapline.ir/ocl_cli/register.php");
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty("User-Agent", USER_AGENT);

			// For POST only - START
			con.setDoOutput(true);
			OutputStream os = con.getOutputStream();
			os.write(("username=" + username).getBytes());
			os.write(("&passwd=" + passwd).getBytes());
			os.write(("&fullname=" + fullname).getBytes());
			os.write(("&addrass=" + addrass).getBytes());
			os.write(("&email=" + email).getBytes());
			os.flush();
			os.close();
			// For POST only - END

			int responseCode = con.getResponseCode();
			System.out.println("POST Response Code :: " + responseCode);
			if (responseCode == HttpURLConnection.HTTP_OK) { // success
				BufferedReader in = new BufferedReader(new InputStreamReader(
						con.getInputStream()));
				String inputLine;
				StringBuffer response = new StringBuffer();

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();

				// print result
				return response.toString();
			} else {
				return "not connected";
			}

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "not connected";
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "not connected";
		}

	}

}